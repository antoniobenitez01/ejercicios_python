# //Conceptos Básicos - Ejercicio 9
# Programa que recoge un texto y muestra su longitud
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca un texto a continuación")
string = input("Texto: ")
print("La longitud del texto es de", len(string), "caracteres.")