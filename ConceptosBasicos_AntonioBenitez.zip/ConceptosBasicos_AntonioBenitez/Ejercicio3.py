# //Conceptos Básicos - Ejercicio 3
# Programa que pide el nombre al usuario y responde con un saludo
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca su nombre")
nombre = input("Nombre: ")
print("Buenos días,", nombre, ".")