# //Conceptos Básicos - Ejercicio 8
# Programa que recoge un texto y lo muestra 5 veces en una misma línea
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca una cadena de texto")
string = input("Texto: ") * 5
print(string)