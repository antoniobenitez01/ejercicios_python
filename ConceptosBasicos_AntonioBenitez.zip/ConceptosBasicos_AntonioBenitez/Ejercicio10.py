# //Conceptos Básicos - Ejercicio 10
# Programa que recoge la edad del usuario y muestra
# la edad que tendrá dentro de 5, 10 y 15 años
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca su edad")
edad = int(input("Edad: "))
print("En 5 años tendrás", edad + 5, "años.")
print("En 10 años tendrás", edad + 10, "años.")
print("En 15 años tendrás", edad + 15, "años.")