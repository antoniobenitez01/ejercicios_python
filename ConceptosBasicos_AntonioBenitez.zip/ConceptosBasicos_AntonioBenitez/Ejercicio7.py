# //Conceptos Básicos - Ejercicio 7
# Programa que recoge un número por teclado y
# muestra su representación en código binario
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca un número por teclado")
x = int(input("Número: "))
print("La representación en binario del número introducido es:", format(x,'b'), ".")