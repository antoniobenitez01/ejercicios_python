# //Conceptos Básicos - Ejercicio 1
# Programa que recoge un valor por teclado y muestra
# de qué tipo es el valor.
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca un valor por teclado.")
x = int(input())
print("El tipo del valor introducido es:", type(x),".")