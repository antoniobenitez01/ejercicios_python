# //Conceptos Básicos - Ejercicio 5 
# Programa que recoge un número y muestra su valor absoluto
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca un número por teclado")
x = int(input("Número: "))
print("El valor absoluto del número introducido es:", abs(x), ".")