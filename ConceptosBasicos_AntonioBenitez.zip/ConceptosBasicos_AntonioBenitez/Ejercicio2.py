# //Conceptos Básicos - Ejercicio 2
# Programa que recoge dos números enteros por teclado y muestra la suma, resta, 
# multiplicación, división real, división entera, resto de división y la potencia de ambos números
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca un número por teclado")
x = int(input("Primer número: "))
print("Introduzca otro número por teclado")
y = int(input("Segundo número: "))
print("Suma:",x+y)
print("Resta:",x-y)
print("Multiplicación:",x*y)
print("División real:",x/y)
print("División entera",x//y)
print("Resto de división entera:",x%y)
print("Potencia:",x**y)