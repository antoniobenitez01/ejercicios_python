# //Conceptos Básicos - Ejercicio 4
# Programa que recoge tres números y calcula su media aritmética
# Autor: Antonio Benítez Rodríguez
# Fecha: 16/09/2025
print("Introduzca 3 números por teclado")
x = int(input("1º Número: "))
y = int(input("2º Número: "))
z = int(input("3º Número: "))
print("La media aritmética de los números introducidos es", (x+y+z)/3, ".")